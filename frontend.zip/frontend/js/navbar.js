// Requiere config.js cargado antes en el HTML

class SaccarumHeader extends HTMLElement {
  connectedCallback() {
    const usuario = getUsuario();
    const sesionActiva = usuario && usuario.nombre;

    const botonesAuth = sesionActiva
      ? `<li><span class="nav-usuario"><i class="bi bi-person-circle"></i> ${usuario.nombre}</span></li>
         <li><a href="perfil.html"><button class="btn-sesion">Mi perfil</button></a></li>
         <li><button class="btn-registro" id="btn-nav-logout">Cerrar sesión</button></li>`
      : `<li><a href="login-register.html"><button class="btn-sesion">Iniciar sesión</button></a></li>
         <li><a href="login-register.html?mode=register"><button class="btn-registro">Registrarse</button></a></li>`;

    this.innerHTML = `
      <header>
        <nav>
          <div class="nav-container">
            <a href="index.html" class="logo">
              <img src="./media/unnamed.png" alt="Saccarum" class="logo">
            </a>
            <ul class="nav-links" id="navLinks">
              <li><a href="index.html">Inicio</a></li>
              <li><a href="cultivos.html">Cultivos</a></li>
              <li><a href="historial.html">Historial</a></li>
              ${botonesAuth}
            </ul>
          </div>
        </nav>
      </header>
    `;

    // --- LÓGICA PARA EL ESTADO ACTIVO ---
    this.setActiveLink();

    // Listener para cerrar sesión
    const btnLogout = this.querySelector('#btn-nav-logout');
    if (btnLogout) {
      btnLogout.addEventListener('click', () => {
        localStorage.removeItem('usuarioSaccarum');
        window.location.href = "login-register.html";
      });
    }
  }

  setActiveLink() {
    const path = window.location.pathname;
    const links = this.querySelectorAll('.nav-links a');

    links.forEach(link => {
      const href = link.getAttribute('href');
      
      // 1. Verificación normal: ¿La URL termina exactamente en el href?
      let isActive = path.endsWith(href);

      // 2. EXCEPCIÓN: Si el enlace es 'cultivos.html' 
      // y estamos en 'DiagnosticoPorCultivo.html', marcar como activo
      if (href === 'cultivos.html' && path.includes('DiagnosticoPorCultivo.html')) {
        isActive = true;
      }

      // Aplicar la clase según el resultado
      if (isActive) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }
}

customElements.define('main-navbar', SaccarumHeader);
