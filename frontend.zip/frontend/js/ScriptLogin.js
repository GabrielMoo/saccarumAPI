// Requiere config.js cargado antes en el HTML

const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');
const formRegister = document.getElementById('form-registro');
const formLogin = document.getElementById('form-sesion');

const params = new URLSearchParams(window.location.search);
const mode = params.get('mode');
if (mode === 'register') {
    container.classList.add("active");
}

registerBtn.addEventListener('click', () => container.classList.add("active"));
loginBtn.addEventListener('click', () => container.classList.remove("active"));

formRegister.addEventListener('submit', function (evento) {
    evento.preventDefault();
    const nombre = document.getElementById('reg-nombre').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const contrasena = document.getElementById('reg-contrasena').value;

    // FIX: validación básica de campos
    if (!nombre) return alert("El nombre no puede estar vacío.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return alert("Escribe un correo válido.");
    if (contrasena.length < 6) return alert("La contraseña debe tener al menos 6 caracteres.");

    fetch(`${API_NODE}/registro`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nombre, email, contrasena })
    })
        .then(respuesta => {
            if (!respuesta.ok) throw new Error(`Error del servidor: ${respuesta.status}`);
            return respuesta.text();
        })
        .then(texto => {
            alert("¡Registro exitoso! Ya puedes iniciar sesión.");
            formRegister.reset();
            container.classList.remove("active");
        })
        .catch(error => {
            console.error("Error al registrar:", error);
            alert("Hubo un problema al registrar. Intenta de nuevo.");
        });
});

formLogin.addEventListener('submit', function (evento) {
    evento.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const contrasena = document.getElementById('login-contrasena').value;

    // FIX: validación básica
    if (!email || !contrasena) return alert("Por favor llena todos los campos.");

    fetch(`${API_NODE}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, contrasena })
    })
        .then(respuesta => {
            if (!respuesta.ok) throw new Error(`Error del servidor: ${respuesta.status}`);
            return respuesta.json();
        })
        .then(datos => {
            if (datos.exito === true) {
                localStorage.setItem('usuarioSaccarum', JSON.stringify(datos.usuario));
                window.location.href = "index.html";
            } else {
                alert("Error: " + datos.mensaje);
            }
        })
        .catch(error => {
            console.error("Error al iniciar sesión:", error);
            alert("Hubo un problema al conectar con el servidor.");
        });
});

function configurarOjo(idInput, idIcono) {
    const input = document.getElementById(idInput);
    const icono = document.getElementById(idIcono);
    if (input && icono) {
        icono.addEventListener('click', function () {
            if (input.type === 'password') {
                input.type = 'text';
                icono.innerHTML = '<i class="bi bi-eye-slash"></i>';
            } else {
                input.type = 'password';
                icono.innerHTML = '<i class="bi bi-eye"></i>';
            }
        });
    }
}

configurarOjo('reg-contrasena', 'icono-ojo');
configurarOjo('login-contrasena', 'icono-ojo-login');
